import React from 'react';
import {
  ActivityIndicator,
  AsyncStorage,
  Button,
  StatusBar,
  StyleSheet,
  View,
  Alert,
  Text,
  TextInput
} from 'react-native';
import { StackNavigator, SwitchNavigator } from 'react-navigation'; // Version can be specified in package.json
import { Constants, Google, BarCodeScanner, Permissions } from 'expo';
import * as firebase from 'firebase'; // Version can be specified in package.json

var firebaseConfig = {
    apiKey: "AIzaSyBLhIpYnOdNDRbuUT-ZHIEXJEyPr92ktzc",
    authDomain: "cqrity-1.firebaseapp.com",
    databaseURL: "https://cqrity-1.firebaseio.com",
    projectId: "cqrity-1",
    storageBucket: "",
    messagingSenderId: "277713640903"
  };
  
// Ensure that you do not login twice.
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

class SignInScreen extends React.Component {
  static navigationOptions = {
    title: 'Registro',
  };

  render() {
    return (
      <View style={styles.container}>
        <Button title="Registro" onPress={this._signInAsync} />
      </View>
    );
  }

  _signInAsync = async () => {
    try {
      const { type, user,idToken, accessToken } = await Google.logInAsync({
        androidStandaloneAppClientId: '<ANDROID_CLIENT_ID>',
        iosStandaloneAppClientId: '<IOS_CLIENT_ID>',
        androidClientId: '277713640903-2i4umgor4fd39cmtuu192fo3hmb1dfrr.apps.googleusercontent.com',
        iosClientId: '',
        scopes: ['profile', 'email']
      });

      switch (type) {
        case 'success': {
          Alert.alert(
            'Logged in!',
            `Hi ${user.name}!`,
          );
          console.log(user);
          console.log(type);
          console.log(idToken);
          console.log(accessToken);
          
          const credential = firebase.auth.GoogleAuthProvider.credential(idToken, accessToken);
          
      firebase.auth().signInWithCredential(credential).then(() => this.props.navigation.navigate('App')).catch((error) => {
            // Handle Errors here.
            console.log("Error authenticating with Google");
            console.log(error);
            console.log(error.message);
          });

          break;
        }
        case 'cancel': {
          Alert.alert(
            'Cancelled!',
            'Login was cancelled!',
          );
          break;
        }
        default: {
          Alert.alert(
            'Oops!',
            'Login failed!',
          );
        }
      }
    } catch (e) {
      Alert.alert(
        'Oops!',
        'Login failed!',
      );
    }
  };
  
}

class HomeScreen extends React.Component {
  static navigationOptions = {
    title: 'cQRity',
  };

  state = {
    hasCameraPermission: null,
  };

  componentDidMount() {
    this._requestCameraPermission();
    this.scanSuccess = false;
  }

  _requestCameraPermission = async () => {
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    this.setState({
      hasCameraPermission: status === 'granted',
    });
  };

  _handleBarCodeRead = ({type, data}) => {
    
    if (this.scanSuccess) return;
    this.scanSuccess = true;
    
    var user = firebase.auth().currentUser.uid;
    //var userId = firebase.auth().currentUser.uid;
    Alert.alert(
//      'Usuario: '+userId,
//      JSON.stringify(user),
      ' Scan successful!'+ user,
      JSON.stringify(data)
    );
    
    var registro = JSON.parse(data)
    
    firebase.database().ref(user + '/' + new Date()+ '/').set({
      registro
    })
    
    this.props.navigation.navigate('Other')
    
  };

  render() {
    return (
      <View style={styles.container}>
        {this.state.hasCameraPermission === null ?
          <Text>Requesting for camera permission</Text> :
          this.state.hasCameraPermission === false ?
            <Text>Camera permission is not granted</Text> :
            <BarCodeScanner
              onBarCodeRead={this._handleBarCodeRead}
              style={{ height: 300, width: 300 }}
            />
        }
        <Button title="Registrar nuevo código" onPress={this.newRecord} />
      </View>
    );
  }

  newRecord = () => {
    this.scanSuccess = false
  }
  
  _showMoreApp = () => {
    this.props.navigation.navigate('Other');
  };

  _signOutAsync = async () => {
    await AsyncStorage.clear();
    this.props.navigation.navigate('Auth');
  };
}

class OtherScreen extends React.Component {
  static navigationOptions = {
    title: 'Lots of features here',
  };
  
  componentDidMount() {
    this.scanSuccess = true;
  }
  
  state = {
    inputValue:"Reporte"
  }
  
  _handleTextChange = inputValue => {
    this.setState({ inputValue });
  };


  render() {
    return (
      <View style={styles.container}>
        <Text>¿Algo que reportar?</Text>
        <TextInput
          value={this.state.inputValue}
          onChangeText={this._handleTextChange}
          style={{ width: 200, height: 150, padding: 8, borderWidth: 1, borderColor: '#ccc' }}
        />
        <Button title="Guardar reporte" onPress={this._handlerTextInput} />
        <StatusBar barStyle="default" />
      </View>
    );
  }
  
  _handlerTextInput = () => {
    var reporte = this.state.inputValue
    //var reporte = {"reporte":reporte}
    Alert.alert (
      'Reporte: '+ JSON.stringify(reporte)
    );
    var user = firebase.auth().currentUser.uid;
    firebase.database().ref(user + '/reportes/' + new Date()+ '/').set({
      reporte
    })
    this.props.navigation.navigate('Home');
  }

  _signOutAsync = async () => {
    await AsyncStorage.clear();
    this.props.navigation.navigate('Auth');
  };
}

class AuthLoadingScreen extends React.Component {
  constructor() {
    super();
    this._bootstrapAsync();
  }

  // Fetch the token from storage then navigate to our appropriate place
  _bootstrapAsync = async () => {
    const userToken = await AsyncStorage.getItem('userToken');

    // This will switch to the App screen or Auth screen and this loading
    // screen will be unmounted and thrown away.
    this.props.navigation.navigate(userToken ? 'App' : 'Auth');
  };

  // Render any loading content that you like here
  render() {
    return (
      <View style={styles.container}>
        <ActivityIndicator />
        <StatusBar barStyle="default" />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

const AppStack = StackNavigator({ Home: HomeScreen, Other: OtherScreen });
const AuthStack = StackNavigator({ SignIn: SignInScreen });

export default SwitchNavigator(
  {
    AuthLoading: AuthLoadingScreen,
    App: AppStack,
    Auth: AuthStack,
  },
  {
    initialRouteName: 'AuthLoading',
  }
);
